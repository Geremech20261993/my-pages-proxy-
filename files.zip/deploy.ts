/**
 * deploy.ts — skeleton deployment script.
 *
 * NOT run or tested in this environment (no RPC/network access here).
 * Fill in addresses.json values, review them yourself on PolygonScan, then
 * run against a fork before mainnet:
 *
 *   npx hardhat run script/deploy.ts --network polygonFork
 *   npx hardhat run script/deploy.ts --network polygon   // after fork validation
 */
import { ethers } from "hardhat";
import addresses from "../addresses.json";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  // ── Sanity-check required addresses are actually filled in ──────────────
  const aavePool = addresses.flashLoanProviders.aaveV3Pool.address;
  const balancerVault = addresses.flashLoanProviders.balancerV2Vault.address;
  if (!aavePool || !balancerVault) {
    throw new Error("Missing required flash loan provider addresses in addresses.json");
  }

  const Router = await ethers.getContractFactory("MultiDEXRouter");
  const router = await Router.deploy();
  await router.waitForDeployment();
  console.log("MultiDEXRouter deployed:", await router.getAddress());

  const Arb = await ethers.getContractFactory("FlashLoanArbitrage");
  const arb = await Arb.deploy(
    aavePool,
    balancerVault,
    await router.getAddress(),
    deployer.address
  );
  await arb.waitForDeployment();
  console.log("FlashLoanArbitrage deployed:", await arb.getAddress());

  // ── Post-deploy config: approve loan asset(s) + set caps ────────────────
  // Do NOT skip this — executeArbitrage reverts for any asset that isn't
  // explicitly approved with a nonzero cap. Set the cap to something you've
  // actually stress-tested, not "unlimited".
  const weth = addresses.tokens.WETH.address;
  await (await arb.setApprovedAsset(weth, true)).wait();
  await (await arb.setMaxLoanAmount(weth, ethers.parseEther("50"))).wait(); // EXAMPLE cap — pick your own
  console.log("WETH approved as loan asset, cap set to 50 WETH (adjust for your risk tolerance)");

  console.log("\nNEXT STEPS (do these before routing real funds):");
  console.log("1. Verify both contracts on PolygonScan.");
  console.log("2. Get an independent security review — this codebase has NOT been audited.");
  console.log("3. Run simulate.ts against current mainnet state before any live execute.ts run.");
  console.log("4. Consider transferring ownership to a multisig (Safe) rather than an EOA.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

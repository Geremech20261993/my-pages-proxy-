// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// NOTE: This suite was written but NOT compiled/run in this environment —
// I don't have network access or a Foundry toolchain available here, so I
// can't fork Polygon mainnet or run `forge test` to confirm it's green.
// Treat this as a starting skeleton, not a passing suite. Before you trust
// it: `forge install foundry-rs/forge-std`, install OpenZeppelin, drop in
// verified addresses, and run it against a real fork.
//
//   forge test --match-path test/FlashLoanArbitrage.t.sol \
//       --fork-url $POLYGON_RPC_URL -vvvv

import "forge-std/Test.sol";
import {FlashLoanArbitrage} from "../src/FlashLoanArbitrage.sol";
import {MultiDEXRouter} from "../src/MultiDEXRouter.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

contract FlashLoanArbitrageTest is Test {
    FlashLoanArbitrage internal arb;
    MultiDEXRouter internal router;

    // --- FILL THESE IN AFTER VERIFYING ON POLYGONSCAN ---
    address internal constant AAVE_V3_POOL = address(0); // TODO: verify
    address internal constant BALANCER_VAULT = address(0); // TODO: verify (this one is the same across most chains: 0xBA12222222228d8Ba445958a75a0704d566BF00 — VERIFY before trusting)
    address internal constant WETH = address(0); // TODO: verify Polygon WETH
    address internal constant USDT = address(0); // TODO
    address internal constant DAI = address(0);  // TODO
    address internal constant USDC = address(0); // TODO

    address internal owner = makeAddr("owner");
    address internal attacker = makeAddr("attacker");

    function setUp() public {
        // vm.createSelectFork(vm.envString("POLYGON_RPC_URL"));
        vm.startPrank(owner);
        router = new MultiDEXRouter();
        arb = new FlashLoanArbitrage(AAVE_V3_POOL, BALANCER_VAULT, address(router), owner);
        vm.stopPrank();
    }

    // ── Access control ─────────────────────────────────────────────────────

    function test_RevertWhen_NonOwnerCallsExecuteArbitrage() public {
        MultiDEXRouter.Hop[] memory hops = new MultiDEXRouter.Hop[](0);
        vm.prank(attacker);
        vm.expectRevert(); // Ownable: caller is not the owner
        arb.executeArbitrage(FlashLoanArbitrage.Provider.AAVE_V3, WETH, 1 ether, hops, 0);
    }

    function test_RevertWhen_NonPoolCallsAaveCallback() public {
        vm.prank(attacker);
        vm.expectRevert(FlashLoanArbitrage.UntrustedCaller.selector);
        arb.executeOperation(WETH, 1 ether, 0, address(arb), "");
    }

    function test_RevertWhen_NonVaultCallsBalancerCallback() public {
        address[] memory tokens = new address[](1);
        uint256[] memory amounts = new uint256[](1);
        uint256[] memory fees = new uint256[](1);
        tokens[0] = WETH;
        vm.prank(attacker);
        vm.expectRevert(FlashLoanArbitrage.UntrustedCaller.selector);
        arb.receiveFlashLoan(tokens, amounts, fees, "");
    }

    // ── Risk controls ──────────────────────────────────────────────────────

    function test_RevertWhen_AssetNotApproved() public {
        MultiDEXRouter.Hop[] memory hops = new MultiDEXRouter.Hop[](0);
        vm.prank(owner);
        vm.expectRevert(FlashLoanArbitrage.AssetNotApproved.selector);
        arb.executeArbitrage(FlashLoanArbitrage.Provider.AAVE_V3, WETH, 1 ether, hops, 0);
    }

    function test_RevertWhen_LoanExceedsCap() public {
        vm.startPrank(owner);
        arb.setApprovedAsset(WETH, true);
        arb.setMaxLoanAmount(WETH, 10 ether);
        vm.stopPrank();

        MultiDEXRouter.Hop[] memory hops = new MultiDEXRouter.Hop[](0);
        vm.prank(owner);
        vm.expectRevert(FlashLoanArbitrage.LoanExceedsCap.selector);
        arb.executeArbitrage(FlashLoanArbitrage.Provider.AAVE_V3, WETH, 100 ether, hops, 0);
    }

    function test_RevertWhen_PausedAndArbitrageAttempted() public {
        vm.startPrank(owner);
        arb.setApprovedAsset(WETH, true);
        arb.setMaxLoanAmount(WETH, 100 ether);
        arb.pause();
        vm.stopPrank();

        MultiDEXRouter.Hop[] memory hops = new MultiDEXRouter.Hop[](0);
        vm.prank(owner);
        vm.expectRevert(); // Pausable: paused
        arb.executeArbitrage(FlashLoanArbitrage.Provider.AAVE_V3, WETH, 1 ether, hops, 0);
    }

    // ── Full round-trip (requires a live fork + verified addresses + real
    //    pool liquidity + a genuinely profitable path to not revert on the
    //    profit check — this is inherently an integration test, not a unit
    //    test; wire it up once addresses/pools are finalized) ─────────────
    function test_FullArbitrageCycle_ProfitEnforced() public {
        vm.skip(true); // unskip once fork + addresses + a real quoted path are in place
    }

    function test_Fuzz_MinProfitBpsBounds(uint256 bps) public {
        vm.prank(owner);
        if (bps == 0 || bps > 2000) {
            vm.expectRevert(FlashLoanArbitrage.InvalidBps.selector);
            arb.setMinProfitBps(bps);
        } else {
            arb.setMinProfitBps(bps);
            assertEq(arb.minProfitBps(), bps);
        }
    }
}
